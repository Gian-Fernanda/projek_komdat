<?php
	session_start();
	include '../config.php';

	if (isset($_POST['login'])) {
		$username = $_POST['username'];
		$password = md5($_POST['password']);
		$nrp = $_POST['nrp'];

		$query = $connect->query("SELECT * FROM user WHERE username='$username' AND password='$password' AND nrp='$nrp'");


		if ($query && $query->num_rows > 0) {
			$data = $query->fetch_assoc();

			if ($password === $data['password']) {
				$_SESSION['username'] = $data['username'];
				$_SESSION['name'] = $data['nama'];
				$_SESSION['level'] = strtolower($data['level']);
				

				// Redirect berdasarkan level
				if ($_SESSION['level'] === 'dosen') {
					header('Location: index.php');
				} else {
					echo "<script>alert('Password salah.'); window.history.back();</script>";
				}
				exit();
			} else {
				echo "<script>alert('Password salah.'); window.history.back();</script>";
			}
		} else {
			echo "<script>alert('Username tidak ditemukan.'); window.history.back();</script>";
		}
	}
?>
