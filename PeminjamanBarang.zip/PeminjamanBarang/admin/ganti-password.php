<?php
session_start();
include '../config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

if (isset($_POST['ubah'])) {
    $pass_lama = md5($_POST['password_lama']);
    $pass_baru = md5($_POST['password_baru']);
    $konfirmasi = md5($_POST['konfirmasi_password']);

    // Ambil password lama dari database
    $query = $connect->query("SELECT password FROM user WHERE username = '$username'");
    $data = $query->fetch_assoc();

    if ($pass_lama !== $data['password']) {
        echo "<script>alert('Password lama salah!');</script>";
    } else {
        if ($pass_baru !== $konfirmasi) {
            echo "<script>alert('Password baru dan konfirmasi tidak cocok!');</script>";
        } else {
            // Update password
            $update = $connect->query("UPDATE user SET password = '$pass_baru' WHERE username = '$username'");
            if ($update) {
                echo "<script>alert('Password berhasil diubah!');</script>";
                header('location: index.php');
            } else {
                echo "<script>alert('Gagal mengubah password!');</script>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title >Admin - Ganti Password</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" type="text/css" href="../tambahan/bootstrap/dist/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../tambahan/bootstrap/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../tambahan/font-awesome/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/register-style.css">
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/themify-icons.css">
    <link rel="stylesheet" href="../assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="../assets/css/cs-skin-elastic.css">
    <!-- <link rel="stylesheet" href="assets/css/bootstrap-select.less"> -->
    <link rel="stylesheet" href="assets/scss/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->

</head>
<body>
<div class="container mt-5">
    <div class="row">
    <div class="col-md-4" style="padding-top: 20px;">
        <a class="btn btn-info btn-icon" href="index.php">
            <i class="fa fa-arrow-left"></i>
        </a>
    </div>
    <div class="col-md-4 form-register-container">
        <h3 style="text-align: center; margin-bottom: 15px;">Ganti Password</h3>
        <form method="POST">
            <div class="form-group">
                <label>Password Lama</label>
                <input type="password" name="password_lama" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Password Baru</label>
                <input type="password" name="password_baru" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Konfirmasi Password Baru</label>
                <input type="password" name="konfirmasi_password" class="form-control" required>
            </div>
            <button type="submit" name="ubah" class="btn btn-primary">Ubah Password</button>
            <a href="index.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
    </div>
</div>

	<script type="text/javascript" src="tambahan/jquery/dist/jquery.min.js"></script>
	<script type="text/javascript" src="tambahan/bootstrap/dist/js/bootstrap.js"></script>
	<script type="text/javascript" src="tambahan/bootstrap/dist/js/bootstrap.min.js"></script>

</body>
</html>
