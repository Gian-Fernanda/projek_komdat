# peminjamanbarangsekolah
1. import database db_pinjam_barang.sql
2. konfigurasi config.php
3. buka http://localhost/peminjamanbarangsekolah
4. login admin: <br>
   username:admin <br>
   password:admin<br>
5. tampilan user
   <img src="http://adlubgs.000webhostapp.com/storage/user.png">
5. tampilan admin
   <img src="http://adlubgs.000webhostapp.com/storage/admin.png">
