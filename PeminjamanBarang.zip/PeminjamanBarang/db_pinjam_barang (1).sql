-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2025 at 04:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pinjam_barang`
--
CREATE DATABASE IF NOT EXISTS `db_pinjam_barang`;
USE `db_pinjam_barang`;
-- --------------------------------------------------------

--
-- Table structure for table `pemberitahuan`
--

CREATE TABLE `pemberitahuan` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `konten` varchar(1000) NOT NULL,
  `status` enum('terima','tolak') NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pemberitahuan`
--

INSERT INTO `pemberitahuan` (`id`, `username`, `konten`, `status`, `timestamp`) VALUES
(29, 'gian', 'Maaf! Permintaan Peminjaman Barang Anda di Tolak. 1 buah Cikrak. Username: gian', 'tolak', '2025-06-09 17:29:30'),
(30, '', 'Maaf! Permintaan Peminjaman Barang Anda di Tolak.  buah . Username: ', 'tolak', '2025-06-09 17:29:36'),
(31, '', 'Maaf! Permintaan Peminjaman Barang Anda di Tolak.  buah . Username: ', 'tolak', '2025-06-09 17:29:42'),
(32, 'gian', 'Maaf! Permintaan Peminjaman Barang Anda di Tolak. 2 buah Speaker kecil. Username: gian', 'tolak', '2025-06-09 17:29:45'),
(33, 'gian', 'Permintaan Peminjaman Barang Anda Telah di Terima. 11 buah Terminal. Username: gian. Silahkan ke bagian Sarpras untuk mengampil barang', 'terima', '2025-06-09 17:53:36'),
(34, 'gian', 'Permintaan Pengembalian Barang Anda Telah di Terima.  buah . Username: ', '', '2025-06-09 17:54:12'),
(35, 'gian', 'Permintaan Peminjaman Barang Anda Telah di Terima. 11 buah Terminal. Username: gian. Silahkan ke bagian Sarpras untuk mengampil barang', 'terima', '2025-06-09 17:55:29'),
(36, 'hendra', 'Permintaan Peminjaman Barang Anda Telah di Terima. 2 buah Cikrak. Username: hendra. Silahkan ke bagian Sarpras untuk mengampil barang', 'terima', '2025-06-09 18:55:36'),
(37, 'hendra', 'Permintaan Pengembalian Barang Anda Telah di Terima.  buah . Username: ', '', '2025-06-09 19:01:26'),
(38, 'irfan', 'Permintaan Peminjaman Barang Anda Telah di Terima. 1 buah Oscilloscope. Username: irfan. Silahkan ke bagian Sarpras untuk mengampil barang', 'terima', '2025-06-10 01:11:32'),
(39, 'irfan', 'Permintaan Pengembalian Barang Anda Telah di Terima.  buah . Username: ', '', '2025-06-10 01:13:26'),
(40, 'irfan', 'Permintaan Peminjaman Barang Anda Telah di Terima. 11 buah Tang Crimping. Username: irfan. Silahkan ke bagian Sarpras untuk mengampil barang', 'terima', '2025-06-10 01:42:38'),
(41, 'irfan', 'Permintaan Pengembalian Barang Anda Telah di Terima.  buah . Username: ', '', '2025-06-10 02:31:42'),
(42, 'irfan', 'Permintaan Peminjaman Barang Anda Telah di Terima. 10 buah Oscilloscope. Username: irfan. Silahkan ke bagian Sarpras untuk mengampil barang', 'terima', '2025-06-10 03:36:33'),
(43, 'gian', 'Permintaan Peminjaman Barang Anda Telah di Terima. 10 buah Tang Crimping. Username: gian. Silahkan ke bagian Sarpras untuk mengampil barang', 'terima', '2025-06-10 08:14:01'),
(44, 'gian', 'Permintaan Peminjaman Barang Anda Telah di Terima. 10 buah Tang Crimping. Username: gian. Silahkan ke bagian Sarpras untuk mengampil barang', 'terima', '2025-06-10 08:14:06'),
(45, 'gian', 'Permintaan Peminjaman Barang Anda Telah di Terima. 10 buah AVOMETER. Username: gian. Silahkan ke bagian Sarpras untuk mengampil barang', 'terima', '2025-06-10 09:55:21'),
(46, 'hendra', 'Maaf! Permintaan Peminjaman Barang Anda di Tolak. 11 buah Tang Crimping. Username: hendra', 'tolak', '2025-06-10 09:55:33'),
(47, 'gian', 'Permintaan Pengembalian Barang Anda Telah di Terima.  buah . Username: ', '', '2025-06-10 15:15:48'),
(48, 'gian', 'Permintaan Peminjaman Barang Anda Telah di Terima. 8 buah AVOMETER. Username: gian. Silahkan ke bagian Sarpras untuk mengampil barang', 'terima', '2025-06-10 15:18:55'),
(49, 'gian', 'Permintaan Pengembalian Barang Anda Telah di Terima.  buah . Username: ', '', '2025-06-10 15:31:29'),
(50, 'hendra', 'Permintaan Peminjaman Barang Anda Telah di Terima. 7 buah AVOMETER. Username: hendra. Silahkan ke bagian Dosen untuk mengampil barang', 'terima', '2025-06-10 15:35:42'),
(51, 'hendra', 'Permintaan Pengembalian Barang Anda Telah di Terima.  buah . Username: ', '', '2025-06-10 15:38:14'),
(52, 'hendra', 'Permintaan Peminjaman Barang Anda Telah di Terima. 9 buah Solder. Username: hendra. Silahkan ke bagian Dosen untuk mengampil barang', 'terima', '2025-06-10 15:40:02');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_barang`
--

CREATE TABLE `tbl_barang` (
  `id` int(11) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `gambar_barang` varchar(100) NOT NULL,
  `stok_barang` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_barang`
--

INSERT INTO `tbl_barang` (`id`, `nama_barang`, `gambar_barang`, `stok_barang`) VALUES
(7, 'Oscilloscope', 'Tektronix_Oscilloscope_475A.jpg', 0),
(9, 'AVOMETER', 'c838b46e-4266-4248-9283-4b0601322249.jpg', 10),
(10, 'Solder', '5acbc6fe-de2b-4875-a7c7-df97de3713d7.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pinjam`
--

CREATE TABLE `tbl_pinjam` (
  `id` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `peminjam` varchar(100) NOT NULL,
  `level` varchar(50) NOT NULL,
  `nrp` varchar(50) NOT NULL,
  `jml_barang` int(50) NOT NULL,
  `tgl_pinjam` varchar(50) NOT NULL,
  `tgl_kembali` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_pinjam`
--

INSERT INTO `tbl_pinjam` (`id`, `nama_barang`, `peminjam`, `level`, `nrp`, `jml_barang`, `tgl_pinjam`, `tgl_kembali`) VALUES
(11, 'Oscilloscope', 'irfan', 'd3tb', '2224500046', 10, '10 Juni 2025 - 10:36 ', '12 Juni 2025 - 14:50 '),
(17, 'Solder', 'hendra', 'd3tb', '2224500034', 9, '10/06/2025 22:39:45', '12/06/2025 22:50:29');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_request`
--

CREATE TABLE `tbl_request` (
  `id` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `peminjam` varchar(50) NOT NULL,
  `level` varchar(50) NOT NULL,
  `nrp` varchar(50) NOT NULL,
  `jml_barang` int(11) NOT NULL,
  `tgl_pinjam` varchar(50) NOT NULL,
  `tgl_kembali` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_request`
--

INSERT INTO `tbl_request` (`id`, `nama_barang`, `peminjam`, `level`, `nrp`, `jml_barang`, `tgl_pinjam`, `tgl_kembali`) VALUES
(26, 'AVOMETER', 'gian', 'd3tb', '2224500046', 9, '11/06/2025 20:57:50', '12/06/2025 21:55:34');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_req_kembali`
--

CREATE TABLE `tbl_req_kembali` (
  `id` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `peminjam` varchar(50) NOT NULL,
  `level` varchar(50) NOT NULL,
  `nrp` varchar(50) NOT NULL,
  `jml_barang` int(11) NOT NULL,
  `tgl_pinjam` varchar(50) NOT NULL,
  `tgl_kembali` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaksi`
--

CREATE TABLE `tbl_transaksi` (
  `id` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `peminjam` varchar(100) NOT NULL,
  `level` varchar(50) NOT NULL,
  `nrp` varchar(50) NOT NULL,
  `jml_barang` int(11) NOT NULL,
  `tgl_pinjam` varchar(50) NOT NULL,
  `tgl_kembali` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_transaksi`
--

INSERT INTO `tbl_transaksi` (`id`, `nama_barang`, `peminjam`, `level`, `nrp`, `jml_barang`, `tgl_pinjam`, `tgl_kembali`) VALUES
(14, 'AVOMETER', 'gian', 'd3tb', '2224500053', 10, '10/06/2025 16:54:39', '12/06/2025 14:30:17'),
(15, 'AVOMETER', 'gian', 'd3tb', '2224500046', 8, '10/06/2025 22:18:29', '12/06/2025 22:30:48'),
(16, 'AVOMETER', 'hendra', 'd3tb', '2224500034', 7, '10/06/2025 22:35:03', '12/06/2025 22:45:46');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` varchar(30) NOT NULL,
  `nrp` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`, `level`, `nrp`) VALUES
(42, 'admin6', 'admin6', '202cb962ac59075b964b07152d234b70', 'Dosen', 0),
(43, 'admin1', 'admin1', '202cb962ac59075b964b07152d234b70', 'Dosen', 0),
(45, 'gian', 'gian', '202cb962ac59075b964b07152d234b70', 'mahasiswa', 0),
(46, 'hendra', 'hendra', '202cb962ac59075b964b07152d234b70', 'mahasiswa', 0),
(47, 'irfan', 'irfan', '202cb962ac59075b964b07152d234b70', 'mahasiswa', 0),
(48, 'ivan', 'ivan', '202cb962ac59075b964b07152d234b70', 'mahasiswa', 0),
(50, 'candra', 'candra', '202cb962ac59075b964b07152d234b70', 'mahasiswa', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pemberitahuan`
--
ALTER TABLE `pemberitahuan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_barang`
--
ALTER TABLE `tbl_barang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pinjam`
--
ALTER TABLE `tbl_pinjam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_request`
--
ALTER TABLE `tbl_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_req_kembali`
--
ALTER TABLE `tbl_req_kembali`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pemberitahuan`
--
ALTER TABLE `pemberitahuan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `tbl_barang`
--
ALTER TABLE `tbl_barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_pinjam`
--
ALTER TABLE `tbl_pinjam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_request`
--
ALTER TABLE `tbl_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tbl_req_kembali`
--
ALTER TABLE `tbl_req_kembali`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
