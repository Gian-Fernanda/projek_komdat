<?php
	include 'config.php';

	if (isset($_POST['daftar'])) {
		$nama 		= $_POST['nama'];
		$username 	= $_POST['username'];
		$password 	= md5($_POST['password']);
		$level		= $_POST['level'];
		$nrp		= $_POST['nrp'];

		// Validasi NRP di server (panjang harus 10 dan hanya angka)
		if (strlen($nrp) != 10 || !is_numeric($nrp)) {
			echo "<script>alert('NRP harus terdiri dari 10 angka.'); window.history.back();</script>";
			exit();
		}

		// Cek apakah username atau nrp sudah ada
		$cek = $connect->query("SELECT * FROM user WHERE username = '$username' OR nrp = '$nrp'");
		if ($cek->num_rows > 0) {
			echo "<script>alert('Username atau NRP sudah terdaftar.'); window.history.back();</script>";
			exit();
		}

		// Jika belum ada, lanjutkan insert
		if ($connect->query("INSERT INTO user (nama, username, password, level, nrp) VALUES ('$nama', '$username', '$password', '$level', '$nrp')")) {
			echo "<script>alert('Berhasil Register'); window.location='login.php';</script>";
		} else {
			echo "<script>alert('Gagal Register'); window.history.back();</script>";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Register | Peminjaman Barang Sekolah</title>
	<link rel="stylesheet" type="text/css" href="tambahan/bootstrap/dist/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="tambahan/bootstrap/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="tambahan/font-awesome/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="assets/css/register-style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>
<body>
	<div class="container">
		<div class='row'>
			<div class="col-md-4"></div>
			<div class="col-md-4 form-register-container">
				<h2 class="" style="text-align:center">Registrasi Akun</h2>
				<form action="" method="post" id="form-register" onsubmit="return validateNRP();">
					<label>Nama</label>
					<input class="form-control" type="text" name="nama" required>
					<label>Username</label>
					<input class="form-control" type="text" name="username" autocomplete="off" required>
					<label>Status</label>
					<select class="form-control" name="level" required>
						<option value="">-- Pilih Status --</option>
						<option value="mahasiswa">Mahasiswa</option>
					</select>
					<label>NRP</label>
					<input class="form-control" type="text" name="nrp" id="nrp" required>
					<br>
					<label>Password</label>
					<input style="margin-bottom: 15px;" class="form-control" type="password" name="password" required>
					
					<label>Sudah punya akun ? Login disini</label>
					<div class="btn">
						<a href="login.php" class="btn btn-success">LOGIN</a>
					</div>

					<div class="row">
						<div class="col-md-6">
							<button type="submit" name="daftar" class="btn btn-success" style="margin-top: 15px;">DAFTAR</button>
						</div>
						<div class="col-md-6">
							<a href="index.php" class="btn btn-danger" style="margin-top: 15px;">BATAL</a>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>

	<!-- Script bawaan -->
	<script type="text/javascript" src="tambahan/jquery/dist/jquery.min.js"></script>
	<script type="text/javascript" src="tambahan/bootstrap/dist/js/bootstrap.js"></script>
	<script type="text/javascript" src="tambahan/bootstrap/dist/js/bootstrap.min.js"></script>

	<!-- Validasi panjang NRP -->
	<script>
	function validateNRP() {
		var nrp = document.getElementById("nrp").value;
		
		if (nrp.length !== 10) {
			alert("NRP harus terdiri dari tepat 10 karakter.");
			return false;
		}

		if (!/^\d+$/.test(nrp)) {
			alert("NRP hanya boleh terdiri dari angka.");
			return false;
		}

		return true;
	}
	</script>
</body>
</html>
