<?php
session_start();
include 'config.php';

if (!in_array($_SESSION['level'], ['mahasiswa'])) {
    header("location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Peminjaman Alat Laboratorium</title>
    <link rel="stylesheet" type="text/css" href="tambahan/bootstrap-4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="tambahan/font-awesome/css/font-awesome.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="#">Peminjaman Alat Laboratorium</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarMain"
            aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menu utama -->
        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav ml-auto">
                <?php if (isset($_SESSION['username'])): ?>
                    <?php $username = $_SESSION['username']; ?>
					<li class="btn btn-outline-secondary btn-sm" data-toggle="collapse" data-target="#menuTop">
						<i class="fa fa-info-circle"></i> Tentang Kami
					</li>
                    <li class="nav-item mx-1">
                        <a href="data-request.php?username=<?= $username ?>" class="btn btn-warning btn-sm">
                            <i class="fa fa-question"></i> Permintaan
                        </a>
                    </li>
                    <li class="nav-item mx-1">
                        <a href="pemberitahuan.php?username=<?= $username ?>" class="btn btn-info btn-sm text-white">
                            <i class="fa fa-globe"></i> Pemberitahuan
                        </a>
                    </li>
                    <li class="nav-item mx-1">
                        <a href="barang-dipinjam.php?username=<?= $username ?>" class="btn btn-primary btn-sm">
                            <i class="fa fa-shopping-cart"></i> Alat Dipinjam
                        </a>
                    </li>
                    <li class="nav-item mx-1">
                        <a href="barang-dikembalikan.php?username=<?= $username ?>" class="btn btn-success btn-sm">
                            <i class="fa fa-check"></i> Alat Dikembalikan
                        </a>
                    </li>
                    <li class="nav-item mx-1">
                        <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
                    </li>
					
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- Collapse Tentang Kami -->
<div class="bg-dark collapse" id="menuTop">
    <div class="container py-3">
        <div class="row">
            <div class="col-md-8 text-white">
                <h4>Tentang Kami</h4>
                <p class="text-muted">Peminjaman Alat Laboratorium adalah aplikasi berbasis web yang dibuat untuk mempermudah pengelolaan peminjaman alat di laboratorium.</p>
            </div>
            <div class="col-md-4 text-white">
                <h4>Kontak</h4>
                <p class="text-muted">
                    <i class="fa fa-phone"></i> +62 812 345 6789<br>
                    <i class="fa fa-envelope"></i> email@email.com
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Main Content -->
<main role="main">
    <section class="jumbotron text-center bg-white">
        <div class="container">
            <h3>Selamat Datang <h3 style="font-style: italic;"><?= $_SESSION['username'] ?? '' ?></h3> </h3>
            
            <h1 class="jumbotron-heading" style="font-style: italic; margin-top: 30px;">Daftar Alat</h1>
            <p>Pilih alat yang ingin dipinjam dari daftar alat di bawah</p>
        </div>
    </section>

    <div class="album py-5 bg-light">
        <div class="container">
            <div class="row">
                <?php
                $query = $connect->query("SELECT * FROM tbl_barang ORDER BY id ASC");
                while ($data = $query->fetch_assoc()):
                ?>
                <div class="col-md-4">
                    <div class="card mb-4 shadow-sm">
                        <img src="assets/img/uploads/<?= $data['gambar_barang']; ?>" class="card-img-top" style="height: 250px; object-fit: cover;">
                        <div class="card-body">
                            <p class="card-text"><?= $data['nama_barang']; ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <?php if ($data['stok_barang'] > 0): ?>
                                        <a href="proses-pinjam.php?username=<?= $username ?>&id_barang=<?= $data['id']; ?>" class="btn btn-sm btn-outline-info">Pinjam</a>
                                    <?php else: ?>
                                        <button class="btn btn-sm btn-outline-secondary" disabled>Stok Habis</button>
                                    <?php endif; ?>
                                </div>
                                <small class="text-muted">Stok: <?= $data['stok_barang']; ?></small>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</main>
<th></th>

<!-- JS Script -->
<script src="tambahan/jquery/dist/jquery.min.js"></script>
<script src="tambahan/bootstrap-4.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
