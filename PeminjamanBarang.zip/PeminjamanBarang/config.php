<?php
	$connect = new mysqli("localhost","root","") or die("Gagal Koneksi");
	if($connect->select_db("db_pinjam_barang")){
		//echo "DATABASE TERPILIH: db_pinjam_barang";
	}
?>
