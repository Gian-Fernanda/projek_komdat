<?php
include 'config.php';

if (!empty($_GET['username']) && $_GET['username'] != "") {
    $id_barang      = $_GET['id_barang'];
    $search_barang  = $connect->query("SELECT * FROM tbl_barang WHERE id='$id_barang'");
    $data           = $search_barang->fetch_assoc();
    $nama_barang    = $data['nama_barang'];
    $stok_barang    = $data['stok_barang'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Peminjaman | Peminjaman Alat Laboratorium</title>
    <link rel="stylesheet" href="tambahan/bootstrap/dist/css/bootstrap.min.css">
    <link href="assets/datepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
    <link rel="stylesheet" href="tambahan/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="assets/css/register-style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="container">
    <div class='row'>
        <div class="col-md-4" style="padding-top: 20px;">
            <a href="index.php" class="btn btn-info btn-icon btn-sm">
                <i class="fa fa-arrow-left"></i>
            </a>
        </div>
        <div class="col-md-4 form-register-container">
            <h2>Peminjaman Alat</h2>
            <form action="request-barang.php" method="post" id="form-pinjam">
                <label>Username</label>
                <input class="form-control" type="text" name="username" required readonly value="<?php echo $_GET['username']; ?>">

                <label>Nama Peminjam</label>
                <input class="form-control" type="text" name="nama_peminjam" required>

                <label>Kelas/Jurusan</label>
                <input class="form-control" type="text" name="level" required>

                <label>NRP</label>
                <input class="form-control" type="text" name="nrp" required>

                <label>Nama Alat</label>
                <input class="form-control" type="text" name="nama_barang" required readonly value="<?php echo $nama_barang; ?>">

                <label>Jumlah</label>
                <input class="form-control" type="number" name="jml_barang" id="jml_barang" min="1" max="<?php echo $stok_barang; ?>" required>
                <input type="hidden" name="id_barang" value="<?php echo $id_barang; ?>">
                <input type="hidden" id="stok_barang" value="<?php echo $stok_barang; ?>">

                <label>Tgl Pinjam</label>
                <div class="input-group date form_datetime">
                    <input class="form-control" type="text" name="tgl_pinjam" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                </div>

                <label>Tgl Kembali</label>
                <div class="input-group date form_datetime">
                    <input class="form-control" type="text" name="tgl_kembali" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                </div>

                <button type="submit" name="request-pinjam" class="btn btn-success" style="margin-top: 20px;">REQUEST</button>
            </form>
        </div>
    </div>
</div>

<?php } else {
    echo "<script>alert('Anda belum login. Silahkan login dulu.'); window.location='login.php';</script>";
} ?>

<script src="tambahan/jquery/dist/jquery.min.js"></script>
<script src="tambahan/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/datepicker/js/bootstrap-datetimepicker.js"></script>
<script src="assets/datepicker/js/locales/bootstrap-datetimepicker.id.js"></script>

<script>
    $('.form_datetime').datetimepicker({
        language:  'id',
        weekStart: 1,
        todayBtn:  1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        forceParse: 0,
        showMeridian: 1
    });

    // Validasi jumlah tidak boleh lebih dari stok
    document.getElementById('form-pinjam').addEventListener('submit', function(e) {
        let stok = parseInt(document.getElementById('stok_barang').value);
        let jml = parseInt(document.getElementById('jml_barang').value);

        if (jml > stok) {
            e.preventDefault();
            alert("Jumlah melebihi stok! Maksimal: " + stok);
        }
    });
</script>

</body>
</html>
